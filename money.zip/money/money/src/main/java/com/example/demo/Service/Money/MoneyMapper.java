package com.example.demo.Service.Money;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.example.demo.Service.dto.MoneyDto;

@Mapper
@Repository
public interface MoneyMapper {
	
	List<MoneyDto> find(MoneyDto dto);
}
