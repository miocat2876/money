package com.example.demo.money;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.Service.Money.MoneyService;
import com.example.demo.Service.dto.MoneyDto;

@Controller
public class MoneyController {
	
	@Autowired
	private MoneyService service;
	
	@ResponseBody
	@PostMapping("/data")
	public List<MoneyDto> data(@RequestBody MoneyDto dto) {
		
		List<MoneyDto> result =  service.find(dto);
	
		return result;
	}
	
	@GetMapping("/")
	public String main() {
		return "academy_info";
	}
	


}
