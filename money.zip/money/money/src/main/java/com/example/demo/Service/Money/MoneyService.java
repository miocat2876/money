package com.example.demo.Service.Money;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Service.dto.MoneyDto;

@Service
public class MoneyService {
	
	
	@Autowired
	private MoneyMapper mapper;
	
	public List<MoneyDto> find(MoneyDto dto) {
		return mapper.find(dto);
	}
	

}
